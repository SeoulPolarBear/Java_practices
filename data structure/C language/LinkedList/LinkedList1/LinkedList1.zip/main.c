#include "linkedlist.h"

const char* cmdstr[] = { "create3", "append1", "push1", "pop", "insertat2",
					"valueat1", "deleteat1", "end" };
void main()
{
	element e;
	int index;
	ListNode* now;
	for (int i = 0; i < 8; i++) {
		printf("(%d) %-9s", i + 1, cmdstr[i]);
		if (i % 3 == 2) printf("\n");
	}
	printf("\n");
	ListNode* head = NULL, * result = NULL, * pre;

	int menu = 1;
	int start = 10, end = 100, step = 12, at;
	head = create(start, end, step);
	print_list(cmdstr[menu - 1], head);


	while (menu != END) {
		printf(">> "); scanf_s("%d", &menu);
		switch (menu) {
		case CREATE:
			scanf_s("%d %d %d", &start, &end, &step);
			head = create(start, end, step);
			break;
		case APPEND:
			scanf_s("%d", &e);
			head = insert(head, NULL, e);
			break;
		case PUSH:
			scanf_s("%d", &e);
			head = insert_first(head, e);
			break;
		case POP:
			head = delete_first(head);
			break;
		case INSERTAT:
			scanf_s("%d %d", &index ,&e);
			now = get_at(head, index - 1);
			head = insert(head, now, e);
			break;
			case VALUEAT:
			scanf_s("%d", &index);
			now=get_at(head, index);
			printf("%d���� ����Ÿ : %d\n", index, now->data);
				break;
		case DELETEAT:
			scanf_s("%d", &index);
			now = get_at(head, index-1);
			head = delete_(head, now);
				break;
		case END: break;
		}
		print_list(cmdstr[menu - 1], head);
	}
}


